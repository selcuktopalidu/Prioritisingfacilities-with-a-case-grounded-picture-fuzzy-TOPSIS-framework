"""Inter-channel agreement statistics: Krippendorff's alpha (nominal / ordinal,
missing allowed), Fleiss' kappa, Cohen's kappa (unweighted / quadratic weights),
percent agreement, Kendall's W."""
import numpy as np
from scipy import stats


def krippendorff_alpha(data, level="nominal", categories=None):
    """data: 2-D array (raters x units) of category codes; np.nan = missing.
    Ordinal metric follows Krippendorff (2004, 2011) using marginal counts."""
    data = np.asarray(data, dtype=float)
    if categories is None:
        categories = np.unique(data[~np.isnan(data)])
    cats = list(categories)
    ci = {c: i for i, c in enumerate(cats)}
    m = len(cats)
    o = np.zeros((m, m))
    for u in range(data.shape[1]):
        vals = data[:, u]
        vals = vals[~np.isnan(vals)]
        mu = len(vals)
        if mu < 2:
            continue
        for a in range(mu):
            for b in range(mu):
                if a != b:
                    o[ci[vals[a]], ci[vals[b]]] += 1.0 / (mu - 1)
    n_c = o.sum(axis=1)
    n = n_c.sum()
    if n <= 1:
        return np.nan
    delta = np.zeros((m, m))
    for c in range(m):
        for k in range(m):
            if c == k:
                continue
            if level == "nominal":
                delta[c, k] = 1.0
            elif level == "ordinal":
                lo, hi = min(c, k), max(c, k)
                delta[c, k] = (n_c[lo:hi + 1].sum() - (n_c[c] + n_c[k]) / 2.0) ** 2
            elif level == "interval":
                delta[c, k] = (cats[c] - cats[k]) ** 2
            else:
                raise ValueError(level)
    Do = (o * delta).sum() / n
    De = (np.outer(n_c, n_c) * delta).sum() / (n * (n - 1))
    if De == 0:
        return 1.0
    return 1.0 - Do / De


def bootstrap_alpha(data, level, n_boot=2000, seed=0, categories=None):
    rng = np.random.default_rng(seed)
    data = np.asarray(data, dtype=float)
    U = data.shape[1]
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(U, size=U)
        vals.append(krippendorff_alpha(data[:, idx], level, categories))
    vals = np.array(vals)
    return np.nanpercentile(vals, [2.5, 97.5]), vals


def fleiss_kappa(data, categories=None):
    """data: raters x units (complete), nominal codes."""
    data = np.asarray(data)
    if categories is None:
        categories = np.unique(data)
    R, U = data.shape
    counts = np.array([[np.sum(data[:, u] == c) for c in categories] for u in range(U)])
    p_j = counts.sum(axis=0) / (U * R)
    P_i = ((counts ** 2).sum(axis=1) - R) / (R * (R - 1))
    P_bar = P_i.mean()
    P_e = (p_j ** 2).sum()
    if P_e == 1:
        return 1.0
    return (P_bar - P_e) / (1 - P_e)


def cohen_kappa(a, b, categories=None, weights=None):
    a, b = np.asarray(a), np.asarray(b)
    mask = ~(np.isnan(a.astype(float)) | np.isnan(b.astype(float)))
    a, b = a[mask], b[mask]
    if categories is None:
        categories = np.unique(np.concatenate([a, b]))
    cats = list(categories)
    m = len(cats)
    ci = {c: i for i, c in enumerate(cats)}
    O = np.zeros((m, m))
    for x, y in zip(a, b):
        O[ci[x], ci[y]] += 1
    n = O.sum()
    E = np.outer(O.sum(1), O.sum(0)) / n
    if weights is None:
        W = 1.0 - np.eye(m)
    elif weights == "quadratic":
        idx = np.arange(m)
        W = ((idx[:, None] - idx[None, :]) ** 2) / ((m - 1) ** 2)
    elif weights == "linear":
        idx = np.arange(m)
        W = np.abs(idx[:, None] - idx[None, :]) / (m - 1)
    num = (W * O).sum()
    den = (W * E).sum()
    if den == 0:
        return 1.0
    return 1.0 - num / den


def kendall_w(rank_matrix):
    """rank_matrix: judges x items (ranks). Returns W, chi2, p (no tie correction)."""
    R = np.asarray(rank_matrix, dtype=float)
    m, n = R.shape
    Ri = R.sum(axis=0)
    S = ((Ri - Ri.mean()) ** 2).sum()
    W = 12 * S / (m ** 2 * (n ** 3 - n))
    chi2 = m * (n - 1) * W
    p = 1 - stats.chi2.cdf(chi2, n - 1)
    return W, chi2, p


if __name__ == "__main__":
    # validation against the krippendorff package (Krippendorff 2011 example)
    import krippendorff
    ex = np.array([
        [1, 2, 3, 3, 2, 1, 4, 1, 2, np.nan, np.nan, np.nan],
        [1, 2, 3, 3, 2, 2, 4, 1, 2, 5, np.nan, 3],
        [np.nan, 3, 3, 3, 2, 3, 4, 2, 2, 5, 1, np.nan],
        [1, 2, 3, 3, 2, 4, 4, 1, 2, 5, 1, np.nan],
    ])
    for lvl in ["nominal", "ordinal", "interval"]:
        mine = krippendorff_alpha(ex, lvl)
        ref = krippendorff.alpha(reliability_data=ex, level_of_measurement=lvl)
        print(lvl, round(mine, 6), round(ref, 6))

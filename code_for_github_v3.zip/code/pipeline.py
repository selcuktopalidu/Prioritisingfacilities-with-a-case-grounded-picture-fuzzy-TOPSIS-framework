"""Core pipeline for the v3 manuscript (PFS constraint Eq. 1; score Eq. 2; distance Eq. 3; PFWA Eq. 4;
separations and closeness with fixed ideals Eqs. 5-6; most-discriminating weights Eq. 7)
and the data appendix (IOA_PF_TOPSIS_Data_Appendix.xlsx).

Pure NumPy. Every function is deterministic given its inputs.
"""
import numpy as np

CASES = ["A1 Gundremmingen 2016", "A2 Luch/Podolsk 1992", "A3 Doel-4 2014",
         "A4 Koeberg 1982", "A5 San Onofre 2012", "A6 Pelindaba 2007",
         "A7 Ignalina 1992"]
CASE_SHORT = ["A1", "A2", "A3", "A4", "A5", "A6", "A7"]
CRITERIA = ["C1 Access", "C2 Authority", "C3 Knowledge", "C4 Malicious intent",
            "C5 Activeness", "C6 Violence potential", "C7 Motivational pressure",
            "C8 Psychosocial vulnerability", "C9 Signal reliability",
            "C10 Detection difficulty", "C11 Potential harm"]
CRIT_SHORT = ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10", "C11"]

# Linguistic scale: label -> (mu, eta, nu) ; pi = 1 - mu - eta - nu  (Table 6)
PFS = {
    "VL": (0.00, 0.00, 0.90), "L": (0.10, 0.10, 0.70), "ML": (0.25, 0.15, 0.50),
    "M": (0.50, 0.20, 0.20), "MH": (0.65, 0.15, 0.10), "H": (0.75, 0.15, 0.05),
    "VH": (0.90, 0.05, 0.02), "CI": (0.30, 0.40, 0.20),
}
TFN = {
    "VL": (0.0, 0.0, 0.1), "L": (0.0, 0.1, 0.3), "ML": (0.1, 0.3, 0.5),
    "M": (0.3, 0.5, 0.7), "MH": (0.5, 0.7, 0.9), "H": (0.7, 0.9, 1.0),
    "VH": (0.9, 1.0, 1.0), "CI": (0.2, 0.45, 0.7),
}
ORDINAL = {"VL": 1, "L": 2, "ML": 3, "M": 4, "MH": 5, "H": 6, "VH": 7}  # CI has no rank

# Channel codings (Sheet 5). Rows = cases A1..A7, columns = C1..C11
# v2 recoding: A2-C5 (Luch, activeness) M -> H in all channels, because the insider personally
# removed the material (IAEA NSS 8-G Rev. 1: active non-violent insider); v1 coded M.
V1_A2_C5 = "M"
CODING = {
    "S1": [
        "M L M VL L VL L ML M H M",
        "H L H H H VL MH MH H VH VH",
        "H MH H H H L CI CI L VH H",
        "H ML H VH VH VH MH L L VH VH",
        "MH M MH CI M L H H CI H MH",
        "VH M VH H H H CI M L VH VH",
        "M L H M M VL CI M CI MH MH",
    ],
    "S2": [
        "M L M VL L VL L ML M MH M",
        "H L H H H VL H MH H VH VH",
        "H MH H H H L CI CI L VH H",
        "H ML H VH VH VH MH L L VH VH",
        "MH M MH CI M L H H CI H MH",
        "VH H VH H H H CI M CI VH VH",
        "M L H CI M VL CI M CI MH MH",
    ],
    "S3": [
        "M L M VL L VL L ML M MH M",
        "H L H H H VL H MH H VH VH",
        "H MH H VH H L CI CI L VH H",
        "H M H VH VH VH MH L L VH VH",
        "MH M MH M M L H H M H MH",
        "VH H VH H H H CI M CI VH VH",
        "M L H CI M VL CI M CI MH MH",
    ],
}
CHANNELS = ["S1", "S2", "S3"]

W0 = np.array([0.12, 0.11, 0.12, 0.10, 0.09, 0.10, 0.08, 0.07, 0.07, 0.07, 0.07])
W_V1 = np.array([0.1044, 0.1102, 0.0603, 0.1081, 0.0747, 0.0813, 0.1536,
                  0.0382, 0.0138, 0.1472, 0.1082])  # weights reported in the v1 draft (not an optimum of Eqs. 9-10)

RISK_CLASSES = [(0.75, "Critical"), (0.60, "Very high"), (0.45, "High"),
                (0.30, "Moderate"), (0.15, "Low"), (-1.0, "Minimal")]


def risk_class(cc):
    for thr, name in RISK_CLASSES:
        if cc >= thr:
            return name
    return "Minimal"


def coding_labels(channel):
    """Return 7x11 array of labels for one channel."""
    return np.array([row.split() for row in CODING[channel]], dtype=object)


def labels_to_pfs(labels, scale=PFS):
    """7x11 label array -> 7x11x3 array of (mu, eta, nu)."""
    out = np.zeros(labels.shape + (3,))
    for i in range(labels.shape[0]):
        for j in range(labels.shape[1]):
            out[i, j] = scale[labels[i, j]]
    return out


def pfwa(stack, wk=None):
    """Picture fuzzy weighted averaging (Eq. 4) over the channel axis (axis 0).
    stack: K x 7 x 11 x 3."""
    K = stack.shape[0]
    if wk is None:
        wk = np.full(K, 1.0 / K)
    wk = np.asarray(wk, dtype=float)[:, None, None]
    mu = 1.0 - np.prod((1.0 - stack[..., 0]) ** wk, axis=0)
    eta = np.prod(stack[..., 1] ** wk, axis=0)
    nu = np.prod(stack[..., 2] ** wk, axis=0)
    return np.stack([mu, eta, nu], axis=-1)


def fuse_channels(scale=PFS, channel_weights=None, channels=CHANNELS, codings=None):
    if codings is None:
        codings = {c: coding_labels(c) for c in channels}
    stack = np.stack([labels_to_pfs(codings[c], scale) for c in channels], axis=0)
    return pfwa(stack, channel_weights)


def pf_distance(a, b):
    """Four-component Euclidean distance (Eq. 3). a, b: (..., 3) arrays of (mu, eta, nu)."""
    pa = 1.0 - a.sum(axis=-1)
    pb = 1.0 - b.sum(axis=-1)
    d2 = (a[..., 0] - b[..., 0]) ** 2 + (a[..., 1] - b[..., 1]) ** 2 \
        + (a[..., 2] - b[..., 2]) ** 2 + (pa - pb) ** 2
    return np.sqrt(0.5 * d2)


def pf_hamming(a, b):
    pa = 1.0 - a.sum(axis=-1)
    pb = 1.0 - b.sum(axis=-1)
    return 0.5 * (np.abs(a[..., 0] - b[..., 0]) + np.abs(a[..., 1] - b[..., 1])
                  + np.abs(a[..., 2] - b[..., 2]) + np.abs(pa - pb))


A_PLUS = np.array([1.0, 0.0, 0.0])   # fixed positive ideal (mu = 1): the ideal insider-threat configuration
A_MINUS = np.array([0.0, 0.0, 1.0])  # fixed negative ideal (nu = 1)


def pf_topsis(agg, w, distance=pf_distance, return_parts=False, ideals="fixed", weighting="distance"):
    """Picture fuzzy TOPSIS on the fused 7x11x3 matrix `agg` with weights `w` (sum 1).
    v2 formulation (default): separations are weighted sums of the four-component distances
    of Eq. (3) to FIXED ideals A+ = (1,0,0,0) and A- = (0,0,1,0):
        d_i^+ = sum_j w_j d(a_ij, A+),  d_i^- = sum_j w_j d(a_ij, A-),  CC_i = d^- / (d^+ + d^-).
    Every quantity stays a picture fuzzy set, CC_i depends on case i only (no rank reversal).
    Options reproduce the v1 formulation for the supplementary comparison:
        ideals="relative": per-criterion ideals = fused values of the best/worst-scoring alternative;
        weighting="exponent": v1 scalar multiplication with lambda_j = n*w_j (violates the PFS
        constraint for lambda < 1) and unweighted distance sums."""
    n = agg.shape[1]
    w = np.asarray(w, dtype=float)
    if weighting == "exponent":
        lam = n * w
        v = np.stack([1.0 - (1.0 - agg[..., 0]) ** lam[None, :], agg[..., 1] ** lam[None, :],
                      agg[..., 2] ** lam[None, :]], axis=-1)
        wd = np.ones(n)
    else:
        v = agg
        wd = w
    if ideals == "relative":
        score = v[..., 0] - v[..., 2]
        ipos = np.argmax(score, axis=0)
        ineg = np.argmin(score, axis=0)
        cols = np.arange(n)
        Apos = v[ipos, cols]
        Aneg = v[ineg, cols]
    else:
        Apos = np.tile(A_PLUS, (n, 1))
        Aneg = np.tile(A_MINUS, (n, 1))
    dpos = (wd[None, :] * distance(v, Apos[None, :, :])).sum(axis=1)
    dneg = (wd[None, :] * distance(v, Aneg[None, :, :])).sum(axis=1)
    cc = dneg / (dpos + dneg)
    if return_parts:
        return cc, dpos, dneg, v
    return cc


def ranks_from_cc(cc):
    """Rank 1 = highest CC."""
    order = np.argsort(-cc, kind="stable")
    r = np.empty_like(order)
    r[order] = np.arange(1, len(cc) + 1)
    return r


# ---------- classical fuzzy TOPSIS baseline (TFN) ----------

def labels_to_tfn(labels):
    out = np.zeros(labels.shape + (3,))
    for i in range(labels.shape[0]):
        for j in range(labels.shape[1]):
            out[i, j] = TFN[labels[i, j]]
    return out


def tfn_distance(a, b):
    return np.sqrt(((a - b) ** 2).sum(axis=-1) / 3.0)


def fuzzy_topsis(w, channels=CHANNELS, codings=None, channel_weights=None):
    """Classical fuzzy TOPSIS baseline (Chen, 2000) with the same mechanism as the PF pipeline:
    channel TFNs averaged (equal channel weights), weighted vertex distances to the fixed ideals
    (1,1,1) and (0,0,0) for benefit criteria, closeness = d- / (d+ + d-)."""
    if codings is None:
        codings = {c: coding_labels(c) for c in channels}
    K = len(channels)
    if channel_weights is None:
        channel_weights = np.full(K, 1.0 / K)
    stack = np.stack([labels_to_tfn(codings[c]) for c in channels], axis=0)
    agg = np.tensordot(np.asarray(channel_weights), stack, axes=(0, 0))  # 7x11x3
    w = np.asarray(w, dtype=float)
    Apos = np.ones(3)
    Aneg = np.zeros(3)
    dpos = (w[None, :] * tfn_distance(agg, Apos[None, None, :])).sum(axis=1)
    dneg = (w[None, :] * tfn_distance(agg, Aneg[None, None, :])).sum(axis=1)
    return dneg / (dpos + dneg)


# ---------- legacy v2 fitness (kept for reference; not used in v3) ----------

def entropy_norm(w):
    w = np.clip(np.asarray(w, dtype=float), 1e-12, None)
    return -(w * np.log(w)).sum() / np.log(len(w))


def consistency(w, w0=W0):
    return 1.0 - 0.5 * np.abs(np.asarray(w) - w0).sum()


def fitness(w, agg, w0=W0, a=2.0, b=0.15, c=0.10):
    cc = pf_topsis(agg, w)
    return a * cc.std(ddof=0) + b * entropy_norm(w) + c * consistency(w, w0)


def project_simplex(w, lb=0.01):
    """Clip to lower bound then renormalise to the unit simplex (iteratively so the
    bound still holds after renormalisation)."""
    w = np.asarray(w, dtype=float).copy()
    for _ in range(50):
        w = np.clip(w, lb, None)
        w = w / w.sum()
        if (w >= lb - 1e-12).all():
            break
    return w

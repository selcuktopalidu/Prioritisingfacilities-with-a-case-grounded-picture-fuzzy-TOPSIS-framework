"""Publication figures (300 dpi PNG + PDF) from results/results.json (v3)."""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pipeline import CASE_SHORT, CRIT_SHORT, W0

R = json.load(open("results/results.json"))
OUT = "figures"; os.makedirs(OUT, exist_ok=True)
BLUE, ORANGE, AQUA, GRAY, INK, MUTED = "#2a78d6", "#eb6834", "#1baf7a", "#9a9a94", "#0b0b0b", "#52514e"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "axes.edgecolor": "#6b6b66", "axes.linewidth": 0.6, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.labelcolor": INK, "legend.frameon": False, "legend.fontsize": 8, "figure.dpi": 100})
CASE_LBL = ["A1 Gundremmingen", "A2 Luch", "A3 Doel-4", "A4 Koeberg", "A5 San Onofre", "A6 Pelindaba", "A7 Ignalina"]
B = R["baseline"]

def save(fig, name):
    fig.savefig(f"{OUT}/{name}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(f"{OUT}/{name}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)

def fig1():
    fig, ax = plt.subplots(figsize=(7.5, 5.0)); ax.set_xlim(0, 100); ax.set_ylim(0, 66); ax.axis("off")
    def box(x, y, w, h, title, body="", fc="#f3f6fb", ec=BLUE, lw=1.0, fs=7.4, title_dy=2.4):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2", fc=fc, ec=ec, lw=lw))
        ax.text(x + w / 2, y + h - title_dy, title, ha="center", va="top", fontsize=fs, fontweight="bold", color=INK, linespacing=1.15)
        if body: ax.text(x + w / 2, y + 2.2, body, ha="center", va="bottom", fontsize=fs - 1.0, color=MUTED, linespacing=1.2)
    def arrow(x1, y1, x2, y2, color="#6b6b66"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=9, lw=0.9, color=color))
    ax.text(1, 65.5, "Layer 1 – Documentary intelligence fusion", fontsize=8, fontweight="bold", color=BLUE, va="top")
    for i, (t, b) in enumerate([("S1 Official /\nregulatory", "IAEA, NRC,\nLANL compendia"), ("S2 Academic\ncase analyses", "Bunn & Sagan;\nBunn (2023)"),
                                 ("S3 Investigative\njournalism", "Center for Public Integrity,\nReuters, Voice of OC")]):
        box(1 + i * 24.5, 49, 22, 13, t, b); arrow(12 + i * 24.5, 49, 30 + 4 * (i - 1), 44.6)
    box(1, 35, 71, 9.5, "Structured coding protocol: 7 cases × 11 criteria × 3 channels", "8-point linguistic scale with a Contested/Indeterminate (CI) label; 231 codes")
    arrow(36.5, 35, 36.5, 30.6)
    box(1, 21, 71, 9.5, "PFWA fusion (Eq. 4): picture fuzzy decision matrix (μ, η, ν, π)", "contested evidence kept as a hedge (neutral membership η, refusal degree π)")
    ax.text(1, 18.2, "Layer 2 – Decision", fontsize=8, fontweight="bold", color=BLUE, va="top")
    box(1, 2, 34, 12, "Criterion weights", "literature prior w⁰ (primary);\nmost-discriminating weights within δ = 0.10 (Eq. 7)", title_dy=2.0)
    box(38, 2, 34, 12, "PF-TOPSIS with fixed ideals\n(Eqs. 5–6)", "weighted four-component distances;\ncloseness CC_i and ranking", title_dy=2.0)
    arrow(30, 21, 18, 14.4); arrow(43, 21, 55, 14.4); arrow(35, 8, 38, 8)
    box(75.5, 2, 23.5, 60, "Layer 3\nStatistical validation", "", fc="#fff4ef", ec=ORANGE, fs=7.6, title_dy=2.2)
    items = ["Inter-channel\ndivergence and\nagreement coefficients", "Monte Carlo rank\nacceptability\n(SMAA-type)", "δ-path and\nre-optimised weights;\nalternative weightings",
             "Distance, channel\nand CI-label\nablations", "Unknown-insider and\n±50% weight\nsensitivity"]
    for k, it in enumerate(items):
        ax.text(87.25, 46.5 - k * 9.9, it, ha="center", va="center", fontsize=6.6, color=INK, linespacing=1.15, bbox=dict(boxstyle="round,pad=0.35", fc="white", ec=ORANGE, lw=0.7))
    arrow(72, 8, 75.5, 8, color=ORANGE)
    save(fig, "fig1_framework")

def fig2():
    cc0, cc1 = np.array(B["cc_prior"]), np.array(B["cc_md"]); m = R["mc"]["WSC"]
    lo, hi = np.array(m["cc_p2_5"]), np.array(m["cc_p97_5"]); order = np.argsort(-cc0)
    fig, ax = plt.subplots(figsize=(6.6, 3.4)); y = np.arange(7)
    ax.errorbar(cc0[order], y, xerr=[cc0[order] - lo[order], hi[order] - cc0[order]], fmt="none", ecolor=ORANGE, elinewidth=1.2, capsize=3, zorder=2,
                label="95% percentile interval, joint weight + scale + coding perturbation (prior-centred)")
    ax.scatter(cc0[order], y, marker="o", s=36, color=BLUE, zorder=4, label="Prior weights $w^0$ (primary)")
    ax.scatter(cc1[order], y, marker="D", s=26, facecolor="white", edgecolor=INK, lw=1.1, zorder=5, label="Most-discriminating weights, δ = 0.10")
    for yi, i in zip(y, order): ax.text(max(hi[i], cc1[i]) + 0.015, yi, f"{cc0[i]:.3f}", va="center", fontsize=7.5, color=INK)
    ax.set_yticks(y); ax.set_yticklabels([CASE_LBL[i] for i in order]); ax.set_ylim(6.6, -0.6)
    ax.set_xlim(0.2, 0.9); ax.set_xlabel("Closeness coefficient $CC_i$ (fixed ideals)"); ax.grid(axis="x", color="#eeeeea", lw=0.6); ax.set_axisbelow(True)
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=1, fontsize=7.2)
    save(fig, "fig2_closeness")

def fig3():
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list("seq", ["#ffffff", "#cde2fb", "#6da7ec", "#2a78d6", "#0d366b"])
    fig, axes = plt.subplots(1, 3, figsize=(7.8, 2.9), sharey=True)
    for ax, (key, title) in zip(axes, [("W100", "(a) Weights around the prior, CV ≈ 30%"), ("U", "(b) Uniform weights"), ("WSC", "(c) Weights + scale + coding")]):
        A = np.array(R["mc"][key]["acceptability"]); im = ax.imshow(A, cmap=cmap, vmin=0, vmax=1, aspect="auto")
        for i in range(7):
            for j in range(7):
                v = A[i, j]
                if v >= 0.005: ax.text(j, i, f"{v:.2f}" if v < 0.995 else "1.00", ha="center", va="center", fontsize=6.4, color="white" if v > 0.55 else INK)
        ax.set_xticks(range(7)); ax.set_xticklabels([str(r) for r in range(1, 8)]); ax.set_yticks(range(7)); ax.set_yticklabels(CASE_LBL)
        ax.set_title(title, fontsize=8); ax.set_xlabel("Rank"); ax.tick_params(length=0)
        for s in ax.spines.values(): s.set_visible(False)
    cb = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02); cb.set_label("Rank acceptability index", fontsize=8); cb.outline.set_visible(False)
    save(fig, "fig3_rank_acceptability")

def fig4():
    path = B["md_path"]; deltas = [p["delta"] for p in path]; Wm = np.array([p["w"] for p in path]); CC = np.array([p["cc"] for p in path])
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.1))
    ax = axes[0]
    styles = {5: (ORANGE, "-"), 3: ("#eda100", "-"), 7: (GRAY, "--"), 8: (GRAY, ":"), 2: (AQUA, "-."), 9: ("#6250d6", (0, (3, 1)))}
    for j in range(11):
        col, ls = styles.get(j, ("#c9c8c2", "-"))
        ax.plot([0] + deltas, [W0[j]] + list(Wm[:, j]), color=col, ls=ls, lw=1.5 if j in styles else 0.9, marker="o", ms=3, label=CRIT_SHORT[j] if j in styles else None)
    ax.axvline(0.10, color=INK, lw=0.7, ls=":"); ax.text(0.12, 0.93, "δ = 0.10 (reported)", fontsize=6.8, color=MUTED, va="top")
    ax.set_xlabel("Total-variation radius δ around the prior"); ax.set_ylabel("Criterion weight"); ax.set_xlim(-0.02, 1.02); ax.set_ylim(0, 0.95)
    ax.grid(color="#eeeeea", lw=0.6); ax.set_axisbelow(True); ax.legend(ncol=3, fontsize=7, loc="upper left", bbox_to_anchor=(0.0, 0.86)); ax.set_title("(a) Most-discriminating weights", fontsize=8.4)
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
    ax = axes[1]
    cc0 = np.array(B["cc_prior"])
    for i, (col, ls) in zip(range(7), [(GRAY, "-"), (AQUA, "-"), ("#6250d6", "--"), (ORANGE, "-"), ("#eda100", "-."), (BLUE, "-"), (GRAY, ":")]):
        ax.plot([0] + deltas, [cc0[i]] + list(CC[:, i]), color=col, ls=ls, lw=1.4, marker="o", ms=3, label=CASE_LBL[i])
    ax.axvline(0.10, color=INK, lw=0.7, ls=":"); ax.set_xlabel("Total-variation radius δ around the prior"); ax.set_ylabel("Closeness coefficient $CC_i$")
    ax.set_xlim(-0.02, 1.02); ax.grid(color="#eeeeea", lw=0.6); ax.set_axisbelow(True); ax.legend(ncol=4, fontsize=6.6, loc="upper center", bbox_to_anchor=(0.5, -0.22)); ax.set_title("(b) Closeness along the path", fontsize=8.4)
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
    save(fig, "fig4_delta_path")

def figS1():
    names = ["IOA", "PSO", "DE", "GA", "RS"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw=dict(width_ratios=[1.15, 1]))
    ax = axes[0]; rng = np.random.default_rng(0); ref = R["bench_stats"]["reference_g"]
    for k, n in enumerate(names):
        d = np.array(R["bench"][n]["f"])
        ax.scatter(k + rng.uniform(-0.18, 0.18, len(d)), ref - d, s=9, color=BLUE if n == "IOA" else GRAY, alpha=0.75, zorder=3)
        ax.hlines(np.median(ref - d), k - 0.3, k + 0.3, color=ORANGE, lw=1.6, zorder=4)
    ax.set_yscale("log"); ax.set_xticks(range(5)); ax.set_xticklabels(names); ax.set_ylabel("Gap to the SLSQP optimum (log scale)")
    ax.grid(axis="y", color="#eeeeea", lw=0.6); ax.set_axisbelow(True); ax.set_title("(a) Final gap, 30 seeds (orange = median)", fontsize=8.2)
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
    ax = axes[1]
    for n, col, ls in [("IOA", BLUE, "-"), ("PSO", GRAY, "--"), ("DE", ORANGE, "-."), ("GA", AQUA, ":"), ("RS", "#6250d6", (0, (1, 1)))]:
        tr = np.array(R["bench"][n]["trace_mean"]); xs = np.arange(len(tr)) * 100
        ax.plot(xs, np.maximum(ref - tr, 1e-6), color=col, ls=ls, lw=1.4, label=n)
    ax.set_yscale("log"); ax.set_xlabel("Objective evaluations"); ax.set_ylabel("Mean gap of best-so-far to optimum")
    ax.grid(color="#eeeeea", lw=0.6); ax.set_axisbelow(True); ax.legend(ncol=2, fontsize=7); ax.set_title("(b) Convergence (mean of 30 runs)", fontsize=8.2)
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
    save(fig, "figS1_benchmark")

if __name__ == "__main__":
    fig1(); fig2(); fig3(); fig4(); figS1(); print("figures written")

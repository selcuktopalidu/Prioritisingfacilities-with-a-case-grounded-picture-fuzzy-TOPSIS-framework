# Reproducibility package (v3) — case-grounded picture fuzzy TOPSIS for insider threats at nuclear facilities

Repository: https://github.com/selcuktopalidu/Prioritisingfacilities-with-a-case-grounded-picture-fuzzy-TOPSIS-framework
(Data Appendix, Supplementary Material and this code folder).

Every value in the manuscript, the supplement and `IOA_PF_TOPSIS_Data_Appendix_v3.xlsx` is produced by the
scripts below with fixed random seeds. Python 3.10+; NumPy, SciPy, Matplotlib, openpyxl
(the `krippendorff` package is used only by the self-test in `agreement.py`). Pin the versions you use
(the run reported in the paper used the versions printed by `python3 -c "import numpy, scipy; print(numpy.__version__, scipy.__version__)"`).

```
python3 analysis.py              # ~17 min: all analyses -> results/results.json
python3 figures.py               # Figs. 1-4 and S1 (300-dpi PNG + PDF) in figures/
python3 workbook.py in/data.xlsx # builds IOA_PF_TOPSIS_Data_Appendix_v3.xlsx
```

| File | Content |
|---|---|
| `pipeline.py` | Linguistic scale, channel codings (A2-C5 recoded to H), PFWA fusion (Eq. 4), PF-TOPSIS with weighted distances to fixed ideals (Eqs. 5-6), fuzzy TOPSIS baseline (Chen 2000, fixed ideals), v1 formulation for Table S8 |
| `optim.py` | Multi-start SLSQP for the most-discriminating weights (Eq. 7); IOA, PSO, DE, GA, random search for the supplementary benchmark (equal budgets, random initialisation) |
| `agreement.py` | Krippendorff's alpha (nominal/ordinal/interval, missing allowed), Fleiss' kappa, Cohen's/weighted kappa; `python3 agreement.py` cross-checks alpha against the `krippendorff` package |
| `analysis.py` | Baseline, delta path, +/-50 % sensitivity, channel divergence, Monte Carlo rank acceptability (W100, W25, U, S, C, P, WSC, MD-W100, MD-WSC, WR), benchmark, alternative weights, distance/channel/CI ablations, unresolved-attribution sensitivity |
| `figures.py`, `workbook.py` | Figures and the data appendix |
| `in/data.xlsx` | The v1 data appendix (Sheets 1-4 and 10 carried over) |

Seeds: delta path SLSQP starts 1; Monte Carlo scenarios 11-19 and 21; bootstrap 1-2; benchmark seeds 1-30; lower bound 0.01.

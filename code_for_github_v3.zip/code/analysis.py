"""Statistical validation pipeline, v3 (revised after review).
Equation numbers refer to the v3 manuscript: PFS constraint (1), score (2), distance (3),
PFWA (4), separations/closeness with fixed ideals (5)-(6), most-discriminating weights (7),
Krippendorff's alpha (8), rank acceptability index (9), WS (10).
Run: python3 analysis.py  ->  results/results.json (every number quoted in the manuscript)."""
import json, os, time, itertools
from collections import Counter
import numpy as np
from scipy import stats
from pipeline import *
from optim import (ioa, pso, de, ga, random_search, most_discriminating, tv, LB)
from agreement import (krippendorff_alpha, bootstrap_alpha, fleiss_kappa, cohen_kappa)

OUT = "results"; os.makedirs(OUT, exist_ok=True)
R = {}
T0 = time.time()
n_crit, n_case = 11, 7
DELTA = 0.10

def spearman(a, b): return float(stats.spearmanr(a, b).correlation)
def kendall(a, b): return float(stats.kendalltau(a, b).correlation)
def ws_coef(rx, ry):
    rx, ry = np.asarray(rx, float), np.asarray(ry, float); N = len(rx)
    return float(1.0 - np.sum(2.0 ** (-rx) * np.abs(rx - ry) / np.maximum(np.abs(rx - 1), np.abs(rx - N))))
def rt(cc): return [int(x) for x in ranks_from_cc(cc)]

# =====================================================================
# 1. Baseline: prior weights (primary) and most-discriminating weights (diagnostic)
# =====================================================================
agg = fuse_channels()
pi_agg = 1 - agg.sum(-1)
std_cc = lambda w: float(pf_topsis(agg, w).std())
cc0, dp0, dn0, _ = pf_topsis(agg, W0, return_parts=True)
RANK0 = rt(cc0)
path = []
for d in [0.05, 0.10, 0.15, 0.20, 0.30, 0.50, 1.00]:
    w, v = most_discriminating(std_cc, d, seed=1)
    cc = pf_topsis(agg, w)
    path.append(dict(delta=d, w=w.tolist(), std_cc=v, tv=tv(w), ranks=rt(cc), cc=cc.tolist()))
W_MD = np.array(next(p for p in path if p["delta"] == DELTA)["w"])
cc1, dp1, dn1, _ = pf_topsis(agg, W_MD, return_parts=True)
RANK1 = rt(cc1)
fz0, fz1 = fuzzy_topsis(W0), fuzzy_topsis(W_MD)
eta_bar = agg[..., 1].mean(axis=1); pi_bar = pi_agg.mean(axis=1)
labs = {c: coding_labels(c) for c in CHANNELS}
n_ci = np.array([(labs[c] == "CI").sum(axis=1) for c in CHANNELS]).sum(axis=0)
delta0 = cc0 - fz0
rho_obs = spearman(eta_bar, delta0)
perm = [spearman(eta_bar, delta0[list(p)]) for p in itertools.permutations(range(7))]
p_perm = float(np.mean(np.abs(perm) >= abs(rho_obs) - 1e-12))
# v1 formulation (relative ideals + exponent weighting) for the supplementary comparison
cc_v1 = pf_topsis(agg, W0, ideals="relative", weighting="exponent")
lam = n_crit * W_V1
v_exp = np.stack([1 - (1 - agg[..., 0]) ** lam, agg[..., 1] ** lam, agg[..., 2] ** lam], -1)
neg_pi_v1 = int(((1 - v_exp.sum(-1)) < -1e-9).sum())
# leave-one-case-out under relative ideals (rank reversal check) vs fixed ideals (none by construction)
loo_rel = []
for drop in range(n_case):
    keep = [i for i in range(n_case) if i != drop]
    cc = pf_topsis(agg[keep], W0, ideals="relative")
    full = cc0[keep]
    loo_rel.append(dict(dropped=CASE_SHORT[drop], ranks_subset=rt(cc), ranks_full_subset=rt(full),
                        reversal=rt(cc) != rt(full), max_abs_cc_change=float(np.abs(cc - pf_topsis(agg, W0, ideals="relative")[keep]).max())))
R["baseline"] = dict(
    w0=W0.tolist(), w_md=W_MD.tolist(), delta=DELTA, tv_md=tv(W_MD), w_v1=W_V1.tolist(),
    cc_prior=cc0.tolist(), dpos_prior=dp0.tolist(), dneg_prior=dn0.tolist(), rank_prior=RANK0,
    cc_md=cc1.tolist(), dpos_md=dp1.tolist(), dneg_md=dn1.tolist(), rank_md=RANK1,
    std_cc_prior=float(cc0.std()), std_cc_md=float(cc1.std()), range_prior=float(cc0.max() - cc0.min()),
    range_md=float(cc1.max() - cc1.min()), fuzzy_prior=fz0.tolist(), fuzzy_md=fz1.tolist(),
    rank_fuzzy_prior=rt(fz0), rank_fuzzy_md=rt(fz1), delta_pf_fuzzy_prior=delta0.tolist(),
    delta_pf_fuzzy_md=(cc1 - fz1).tolist(), spearman_pf_fuzzy_prior=spearman(cc0, fz0), kendall_pf_fuzzy_prior=kendall(cc0, fz0),
    range_fuzzy_prior=float(fz0.max() - fz0.min()), eta_bar=eta_bar.tolist(), pi_bar=pi_bar.tolist(), n_ci_codes=n_ci.tolist(),
    rho_eta_delta=rho_obs, p_perm_eta_delta=p_perm, md_path=path, lower_bound=LB,
    v1_formulation_cc_prior=cc_v1.tolist(), v1_formulation_ranks_prior=rt(cc_v1), v1_cells_negative_pi_at_w_v1=neg_pi_v1,
    loo_relative=loo_rel, loo_relative_any_reversal=bool(any(x["reversal"] for x in loo_rel)),
    a2_c5_v1=V1_A2_C5,
)
# lower bound sensitivity of the MD-0.10 solution
R["lower_bound"] = []
for lb in [0.01, 0.02, 0.05]:
    w, v = most_discriminating(std_cc, DELTA, lb=lb, seed=1)
    R["lower_bound"].append(dict(lb=lb, w=w.tolist(), std_cc=v, ranks=rt(pf_topsis(agg, w))))
print("baseline done", round(time.time() - T0, 1))

# =====================================================================
# 2. One-at-a-time +/-50 % around the prior and around MD-0.10
# =====================================================================
oat = {}
for name, base in [("prior", W0), ("md", W_MD)]:
    rows = []
    for j in range(n_crit):
        for fac, lab in [(1.5, "+50%"), (0.5, "-50%")]:
            w = base.copy(); w[j] *= fac; w = w / w.sum()
            cc = pf_topsis(agg, w); rows.append(dict(criterion=CRIT_SHORT[j], change=lab, ranks=rt(cc), cc=cc.tolist()))
    rk = np.array([r["ranks"] for r in rows])
    oat[name] = dict(rows=rows, rank_range=[[int(rk[:, i].min()), int(rk[:, i].max())] for i in range(n_case)],
                     n_changed=int(sum(r["ranks"] != (RANK0 if name == "prior" else RANK1) for r in rows)))
R["oat"] = oat
gaps0 = np.diff(np.sort(cc0)); R["adjacent_gaps_prior"] = {f"{CASE_SHORT[a]}-{CASE_SHORT[b]}": float(cc0[a] - cc0[b]) for a, b in zip(np.argsort(-cc0)[:-1], np.argsort(-cc0)[1:])}
R["adjacent_gaps_md"] = {f"{CASE_SHORT[a]}-{CASE_SHORT[b]}": float(cc1[a] - cc1[b]) for a, b in zip(np.argsort(-cc1)[:-1], np.argsort(-cc1)[1:])}

# =====================================================================
# 3. Inter-channel agreement (descriptive)
# =====================================================================
cells = [(i, j) for i in range(n_case) for j in range(n_crit)]
NOM = {"VL": 1, "L": 2, "ML": 3, "M": 4, "MH": 5, "H": 6, "VH": 7, "CI": 8}
ORD2 = {"VL": 1, "L": 2, "ML": 3, "CI": 3.5, "M": 4, "MH": 5, "H": 6, "VH": 7}   # CI placed between ML and M
nominal = np.array([[NOM[labs[c][i, j]] for (i, j) in cells] for c in CHANNELS], float)
ordinal = np.array([[ORDINAL.get(labs[c][i, j], np.nan) for (i, j) in cells] for c in CHANNELS], float)
ordinal2 = np.array([[ORD2[labs[c][i, j]] for (i, j) in cells] for c in CHANNELS], float)
full_agree = np.array([len(set(labs[c][i, j] for c in CHANNELS)) == 1 for (i, j) in cells])
a_nom = krippendorff_alpha(nominal, "nominal"); a_ord = krippendorff_alpha(ordinal, "ordinal"); a_ord2 = krippendorff_alpha(ordinal2, "ordinal")
ci_nom, _ = bootstrap_alpha(nominal, "nominal", 2000, seed=1); ci_ord, _ = bootstrap_alpha(ordinal, "ordinal", 2000, seed=2)
pairs = {}
for a, b in [("S1", "S2"), ("S1", "S3"), ("S2", "S3")]:
    ia, ib = CHANNELS.index(a), CHANNELS.index(b)
    pairs[f"{a}-{b}"] = dict(pct=float(np.mean(nominal[ia] == nominal[ib])), n_diff=int(np.sum(nominal[ia] != nominal[ib])),
                             kappa=cohen_kappa(nominal[ia], nominal[ib]),
                             wkappa_quadratic=cohen_kappa(ordinal[ia], ordinal[ib], categories=list(range(1, 8)), weights="quadratic"))
per_crit = [dict(criterion=CRITERIA[j], n_divergent=int(sum(not full_agree[k] for k, (i, jj) in enumerate(cells) if jj == j)),
                 n_ci_any=int(sum((nominal[:, k] == 8).any() for k, (i, jj) in enumerate(cells) if jj == j))) for j in range(n_crit)]
per_case = [dict(case=CASES[i], n_divergent=int(sum(not full_agree[k] for k, (ii, j) in enumerate(cells) if ii == i)),
                 n_ci_any=int(sum((nominal[:, k] == 8).any() for k, (ii, j) in enumerate(cells) if ii == i))) for i in range(n_case)]
cc_ch = {c: pf_topsis(fuse_channels(codings={c: labs[c]}, channels=[c]), W0) for c in CHANNELS}
R["agreement"] = dict(n_cells=len(cells), n_full_agree=int(full_agree.sum()), n_divergent=int((~full_agree).sum()),
                      pct_full_agree=float(full_agree.mean()), n_ci_cells_any=int(sum((nominal[:, k] == 8).any() for k in range(len(cells)))),
                      n_ci_codes_total=int((nominal == 8).sum()), alpha_nominal=a_nom, alpha_nominal_ci=ci_nom.tolist(),
                      alpha_ordinal=a_ord, alpha_ordinal_ci=ci_ord.tolist(), alpha_ordinal_ci_between=a_ord2,
                      n_units_ordinal=int(((~np.isnan(ordinal)).sum(axis=0) >= 2).sum()), fleiss_kappa=fleiss_kappa(nominal.astype(int)),
                      pairs=pairs, per_criterion=per_crit, per_case=per_case,
                      channel_cc={c: cc_ch[c].tolist() for c in CHANNELS}, channel_ranks={c: rt(cc_ch[c]) for c in CHANNELS},
                      channel_max_cc_diff=float(max(max(cc_ch[c][i] for c in CHANNELS) - min(cc_ch[c][i] for c in CHANNELS) for i in range(n_case))))
print("agreement done", round(time.time() - T0, 1))

# =====================================================================
# 4. Monte Carlo rank acceptability
# =====================================================================
ORD_LIST = ["VL", "L", "ML", "M", "MH", "H", "VH"]

def perturb_scale(rng, sd=0.05):
    """Gaussian noise on (mu, eta, nu) of every label, clipped, rescaled to keep pi >= 0;
    redrawn until the mu values of VL..VH remain strictly increasing (monotone scale)."""
    for attempt in range(200):
        sc = {}
        for k, (mu, eta, nu) in PFS.items():
            v = np.clip(np.array([mu, eta, nu]) + rng.normal(0, sd, 3), 0.0, 1.0)
            s0 = mu + eta + nu
            if v.sum() > s0:
                v = v * (s0 / v.sum())
            sc[k] = tuple(v)
        mus = [sc[k][0] for k in ORD_LIST]
        if all(np.diff(mus) > 0):
            return sc, attempt
    return sc, attempt

def perturb_coding(rng, p_step=0.10, p_ci_to_point=0.10, p_point_to_ci=0.03):
    out = {}
    for c in CHANNELS:
        L = labs[c].copy()
        for i in range(n_case):
            for j in range(n_crit):
                lab = L[i, j]; u = rng.random()
                if lab == "CI":
                    if u < p_ci_to_point: L[i, j] = "M"
                elif u < p_step:
                    k = min(6, max(0, ORD_LIST.index(lab) + (1 if rng.random() < 0.5 else -1))); L[i, j] = ORD_LIST[k]
                elif u < p_step + p_point_to_ci:
                    L[i, j] = "CI"
        out[c] = L
    return out

def perturb_coding_correlated(rng, p_case=0.25):
    """Sceptical/charitable recoder: with probability p_case a case's point ratings move one step
    in the same direction in all channels (stress test with correlated errors)."""
    out = {c: labs[c].copy() for c in CHANNELS}
    for i in range(n_case):
        if rng.random() < p_case:
            step = 1 if rng.random() < 0.5 else -1
            for c in CHANNELS:
                for j in range(n_crit):
                    lab = out[c][i, j]
                    if lab != "CI":
                        out[c][i, j] = ORD_LIST[min(6, max(0, ORD_LIST.index(lab) + step))]
    return out

def mc(scenario, n_draw=10000, seed=2026, kappa=100.0, centre=None, ref_rank=None):
    rng = np.random.default_rng(seed)
    centre = W0 if centre is None else centre
    ref = RANK0 if ref_rank is None else ref_rank
    ranks = np.zeros((n_draw, n_case), int); ccs = np.zeros((n_draw, n_case)); wsamp = []; rejects = 0
    for d in range(n_draw):
        w = centre; A = agg
        if "W" in scenario: w = project_simplex(rng.dirichlet(kappa * centre), LB); wsamp.append(w)
        if "U" in scenario: w = project_simplex(rng.dirichlet(np.ones(n_crit)), LB); wsamp.append(w)
        if "S" in scenario or "C" in scenario or "P" in scenario:
            sc = PFS
            if "S" in scenario:
                sc, att = perturb_scale(rng); rejects += att
            cod = labs
            if "C" in scenario: cod = perturb_coding(rng)
            if "P" in scenario: cod = perturb_coding_correlated(rng)
            A = fuse_channels(scale=sc, codings=cod)
        cc = pf_topsis(A, w); ccs[d] = cc; ranks[d] = ranks_from_cc(cc)
    acc = np.array([[np.mean(ranks[:, i] == r) for r in range(1, n_case + 1)] for i in range(n_case)])
    same = float(np.mean([list(r) == ref for r in ranks]))
    rho = np.array([spearman(ref, r) for r in ranks]); tau = np.array([kendall(ref, r) for r in ranks])
    order = np.argsort(ref); rev = {}
    for a, b in zip(order[:-1], order[1:]):
        rev[f"{CASE_SHORT[a]}>{CASE_SHORT[b]}"] = float(np.mean(ccs[:, a] < ccs[:, b]))
    top2 = float(np.mean([set(np.argsort(r)[:2]) == {3, 5} for r in ranks]))
    out = dict(scenario=scenario, n_draw=n_draw, kappa=kappa if "W" in scenario else None, reference=ref,
               acceptability=acc.tolist(), p_same_ranking=same, p_top_A6=float(np.mean(ranks[:, 5] == 1)),
               p_top2_A6_A4=top2, p_last_A1=float(np.mean(ranks[:, 0] == 7)), p_sixth_A7=float(np.mean(ranks[:, 6] == 6)),
               rho_mean=float(rho.mean()), rho_p5=float(np.percentile(rho, 5)), rho_min=float(rho.min()),
               tau_mean=float(tau.mean()), tau_p5=float(np.percentile(tau, 5)),
               cc_mean=ccs.mean(0).tolist(), cc_sd=ccs.std(0).tolist(), cc_p2_5=np.percentile(ccs, 2.5, axis=0).tolist(),
               cc_p97_5=np.percentile(ccs, 97.5, axis=0).tolist(), expected_rank=(acc * np.arange(1, n_case + 1)).sum(1).tolist(),
               p_adjacent_reversal=rev, scale_redraws=rejects)
    if wsamp:
        W = np.array(wsamp); out["w_p2_5"] = np.percentile(W, 2.5, axis=0).tolist(); out["w_p97_5"] = np.percentile(W, 97.5, axis=0).tolist()
        out["w_mean"] = W.mean(0).tolist()
    return out

MC = {}
MC["W100"] = mc("W", kappa=100.0, seed=11)
MC["W25"] = mc("W", kappa=25.0, seed=12)
MC["U"] = mc("U", seed=13)
MC["S"] = mc("S", seed=14)
MC["C"] = mc("C", seed=15)
MC["P"] = mc("P", seed=17)
MC["WSC"] = mc("WSC", kappa=100.0, seed=16)
MC["MD_W100"] = mc("W", kappa=100.0, seed=18, centre=W_MD, ref_rank=RANK1)
MC["MD_WSC"] = mc("WSC", kappa=100.0, seed=19, centre=W_MD, ref_rank=RANK1)
# re-optimised weights per perturbed matrix (scale + coding perturbation, MD-0.10 recomputed each draw)
rng = np.random.default_rng(21); n_re = 500; rk_re = []; w_re = []
for d in range(n_re):
    sc, _ = perturb_scale(rng); cod = perturb_coding(rng); A = fuse_channels(scale=sc, codings=cod)
    w, v = most_discriminating(lambda w: float(pf_topsis(A, w).std()), DELTA, starts=2, seed=d)
    rk_re.append(rt(pf_topsis(A, w))); w_re.append(w)
rk_re = np.array(rk_re); w_re = np.array(w_re)
MC["WR"] = dict(scenario="WR", n_draw=n_re, reference=RANK1,
                acceptability=[[float(np.mean(rk_re[:, i] == r)) for r in range(1, 8)] for i in range(n_case)],
                p_same_ranking=float(np.mean([list(r) == RANK1 for r in rk_re])), p_top_A6=float(np.mean(rk_re[:, 5] == 1)),
                p_top2_A6_A4=float(np.mean([set(np.argsort(r)[:2]) == {3, 5} for r in rk_re])), p_last_A1=float(np.mean(rk_re[:, 0] == 7)),
                p_sixth_A7=float(np.mean(rk_re[:, 6] == 6)), rho_mean=float(np.mean([spearman(RANK1, r) for r in rk_re])),
                tau_mean=float(np.mean([kendall(RANK1, r) for r in rk_re])), w_mean=w_re.mean(0).tolist(), w_sd=w_re.std(0).tolist(),
                p_c6_largest=float(np.mean(np.argmax(w_re, axis=1) == 5)), p_c8_at_bound=float(np.mean(w_re[:, 7] <= LB + 1e-9)),
                p_c9_at_bound=float(np.mean(w_re[:, 8] <= LB + 1e-9)))
R["mc"] = MC
with open(f"{OUT}/results_partial.json", "w") as fh:
    json.dump(R, fh, default=float)
R["mc_weight_ranges"] = {k: dict(p2_5=MC[k]["w_p2_5"], p97_5=MC[k]["w_p97_5"]) for k in ["W100", "W25"]}
print("MC done", round(time.time() - T0, 1))

# =====================================================================
# 5. Supplementary benchmark: population methods on the penalised MD objective, equal budgets
# =====================================================================
PEN = 10.0
def g(w):
    return std_cc(w) - PEN * max(0.0, tv(w) - DELTA)
w_ref, v_ref = most_discriminating(std_cc, DELTA, starts=40, seed=2)
g_ref = g(w_ref)
seeds = list(range(1, 31)); bench = {}
for name, fn in [("IOA", ioa), ("PSO", pso), ("DE", de), ("GA", ga), ("RS", random_search)]:
    fs, ws, traces, evals = [], [], [], []
    for s in seeds:
        B = fn(g, seed=s, max_evals=6000); fs.append(B.best_f); ws.append(B.best_w); traces.append(np.array(B.trace)); evals.append(B.n)
    fs, ws = np.array(fs), np.array(ws)
    rk = [rt(pf_topsis(agg, w)) for w in ws]
    tr = np.array([np.pad(t, (0, 6000 - len(t)), mode="edge")[:6000] for t in traces])
    bench[name] = dict(f=fs.tolist(), w=ws.tolist(), evals=evals, f_mean=float(fs.mean()), f_sd=float(fs.std(ddof=1)),
                       f_median=float(np.median(fs)), f_min=float(fs.min()), f_max=float(fs.max()),
                       success={str(t): float(np.mean(fs >= g_ref - t)) for t in [2e-4, 5e-4, 1e-3]},
                       p_md_ranking=float(np.mean([r == RANK1 for r in rk])), rankings=[(list(k), v) for k, v in Counter(tuple(r) for r in rk).most_common()],
                       w_mean=ws.mean(0).tolist(), trace_mean=tr.mean(0)[::100].tolist(), tv_mean=float(np.mean([tv(w) for w in ws])),
                       l1_to_ref_mean=float(np.mean([np.abs(w - w_ref).sum() for w in ws])))
names = ["IOA", "PSO", "DE", "GA", "RS"]
def a12(x, y):
    x, y = np.asarray(x), np.asarray(y)
    return float((np.sum(x[:, None] > y[None, :]) + 0.5 * np.sum(x[:, None] == y[None, :])) / (len(x) * len(y)))
pw = {}; keys = []
for a, b in itertools.combinations(names, 2):
    x, y = np.array(bench[a]["f"]), np.array(bench[b]["f"])
    p = float(stats.mannwhitneyu(x, y, alternative="two-sided").pvalue) if not np.allclose(x, y) else 1.0
    pw[f"{a} vs {b}"] = dict(p_raw=p, A12=a12(x, y)); keys.append(f"{a} vs {b}")
pv = np.array([pw[k]["p_raw"] for k in keys]); order = np.argsort(pv); m = len(pv); run = 0.0; holm = np.empty(m)
for rnk, idx in enumerate(order):
    run = max(run, min(1.0, (m - rnk) * pv[idx])); holm[idx] = run
for i, k in enumerate(keys): pw[k]["p_holm"] = float(holm[i])
kw = stats.kruskal(*[bench[n]["f"] for n in names])
R["bench"] = bench
rank_mat = np.array([stats.rankdata(-np.array([bench[k]["f"][s] for k in names])) for s in range(30)])
R["bench_stats"] = dict(reference_w=w_ref.tolist(), reference_g=g_ref, reference_std=v_ref, penalty=PEN, budget=6000,
                        kruskal_H=float(kw.statistic), kruskal_p=float(kw.pvalue), pairwise=pw,
                        mean_rank={n: float(rank_mat[:, i].mean()) for i, n in enumerate(names)})
print("benchmark done", round(time.time() - T0, 1))

# =====================================================================
# 6. Alternative weighting schemes
# =====================================================================
S = agg[..., 0] - agg[..., 2]; P = (S + 1) / 2.0; Pn = P / P.sum(axis=0, keepdims=True)
with np.errstate(divide="ignore", invalid="ignore"):
    e_j = -(np.nan_to_num(Pn * np.log(Pn))).sum(axis=0) / np.log(n_case)
w_entropy = (1 - e_j) / (1 - e_j).sum()
Z = (P - P.min(0)) / np.where(P.max(0) - P.min(0) == 0, 1, P.max(0) - P.min(0))
sig = Z.std(axis=0, ddof=1); corr = np.nan_to_num(np.corrcoef(Z.T), nan=0.0)
w_critic = (sig * (1 - corr).sum(axis=1)); w_critic = w_critic / w_critic.sum()
alt = {}
for name, w in [("Equal", np.full(n_crit, 1 / n_crit)), ("Prior", W0), ("Entropy", w_entropy), ("CRITIC", w_critic), ("MD-0.10", W_MD)]:
    cc = pf_topsis(agg, w)
    alt[name] = dict(w=np.asarray(w).tolist(), cc=cc.tolist(), ranks=rt(cc), std_cc=float(cc.std()),
                     spearman_vs_prior=spearman(cc0, cc), kendall_vs_prior=kendall(cc0, cc), ws_vs_prior=ws_coef(RANK0, rt(cc)))
R["alt_weights"] = alt

# =====================================================================
# 7. Distance, channel weights, leave-one-channel-out (prior weights)
# =====================================================================
dh = pf_topsis(agg, W0, distance=pf_hamming)
R["distance"] = dict(hamming_cc=dh.tolist(), hamming_ranks=rt(dh), spearman=spearman(cc0, dh))
chan = {}
for name, cw in [("Equal", None), ("Official-heavy", [0.5, 0.25, 0.25]), ("Academic-heavy", [0.25, 0.5, 0.25]), ("Press-heavy", [0.25, 0.25, 0.5])]:
    cc = pf_topsis(fuse_channels(channel_weights=cw), W0); chan[name] = dict(cc=cc.tolist(), ranks=rt(cc), spearman=spearman(cc0, cc))
loo = {}
for drop in CHANNELS:
    keep = [c for c in CHANNELS if c != drop]
    cc = pf_topsis(fuse_channels(channels=keep, codings={c: labs[c] for c in keep}), W0); loo[f"without {drop}"] = dict(cc=cc.tolist(), ranks=rt(cc), spearman=spearman(cc0, cc))
R["channel_weights"] = chan; R["loo_channel"] = loo

# =====================================================================
# 8. CI label analyses (prior weights): eta sweep, eta/pi swap, IF ablation, point substitutes
# =====================================================================
sweep = []
for eta in [0.0, 0.10, 0.20, 0.30, 0.40, 0.50]:
    sc = dict(PFS); sc["CI"] = (0.30, eta, 0.20); cc = pf_topsis(fuse_channels(scale=sc), W0)
    sweep.append(dict(eta_ci=eta, pi_ci=round(0.5 - eta, 2), cc=cc.tolist(), ranks=rt(cc), max_abs_change=float(np.abs(cc - cc0).max())))
# eta/pi swap of every label
sc_swap = {k: (mu, 1 - mu - eta - nu, nu) for k, (mu, eta, nu) in PFS.items()}
cc_swap = pf_topsis(fuse_channels(scale=sc_swap), W0)
# IF ablation: eta merged into pi (eta = 0, pi = eta + pi)
sc_if = {k: (mu, 0.0, nu) for k, (mu, eta, nu) in PFS.items()}
cc_if = pf_topsis(fuse_channels(scale=sc_if), W0); fz_if = fz0
ci_sub = {}
for lab in ["L", "ML", "M", "MH"]:
    cod = {c: np.where(labs[c] == "CI", lab, labs[c]) for c in CHANNELS}
    cc = pf_topsis(fuse_channels(codings=cod), W0); ff = fuzzy_topsis(W0, codings=cod)
    ci_sub[f"CI->{lab}"] = dict(cc=cc.tolist(), ranks=rt(cc), fuzzy_cc=ff.tolist(), fuzzy_ranks=rt(ff))
R["ci"] = dict(sweep=sweep, swap_cc=cc_swap.tolist(), swap_ranks=rt(cc_swap), swap_max_abs_change=float(np.abs(cc_swap - cc0).max()),
               if_ablation_cc=cc_if.tolist(), if_ablation_ranks=rt(cc_if), if_ablation_max_abs_change=float(np.abs(cc_if - cc0).max()),
               substitution=ci_sub, score_ci=float(PFS["CI"][0] - PFS["CI"][2]), tfn_ci_centroid=float(np.mean(TFN["CI"])))

# =====================================================================
# 9. Unknown-insider sensitivity: insider-specific attributes of unresolved cases set to CI
# =====================================================================
INSIDER_CRIT = [0, 1, 2, 6, 7]   # C1 access, C2 authority, C3 knowledge, C7 motive, C8 psychosocial
unk = {}
for name, cases in [("A3 Doel-4", [2]), ("A5 San Onofre", [4]), ("A6 Pelindaba", [5]), ("A3+A5+A6", [2, 4, 5])]:
    cod = {c: labs[c].copy() for c in CHANNELS}
    for c in CHANNELS:
        for i in cases:
            for j in INSIDER_CRIT:
                cod[c][i, j] = "CI"
    A = fuse_channels(codings=cod); cc = pf_topsis(A, W0); ccm = pf_topsis(A, W_MD)
    unk[name] = dict(cc_prior=cc.tolist(), ranks_prior=rt(cc), cc_md=ccm.tolist(), ranks_md=rt(ccm))
R["unknown_insider"] = unk

R["runtime_s"] = time.time() - T0
with open(f"{OUT}/results.json", "w") as fh:
    json.dump(R, fh, indent=1, default=float)
print("ALL DONE", round(time.time() - T0, 1))

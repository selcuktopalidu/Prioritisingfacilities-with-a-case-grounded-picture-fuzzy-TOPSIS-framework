"""Optimisers on the bounded unit simplex (lb = 0.01) for the supplementary benchmark:
IOA (cellular PSO-like scheme, Eq. 4), PSO, DE, GA, random search, and a deterministic
multi-start SLSQP for the constrained most-discriminating-weights problem.
All consume the same objective callable and share an identical evaluation budget and
random initialisation (no warm start)."""
import numpy as np
from scipy.optimize import minimize
from pipeline import project_simplex, W0

LB = 0.01


class Budget:
    """Counts evaluations, keeps the best, and enforces a hard cap."""
    def __init__(self, f, max_evals=6000):
        self.f = f
        self.max_evals = max_evals
        self.n = 0
        self.best_f = -np.inf
        self.best_w = None
        self.trace = []

    @property
    def exhausted(self):
        return self.n >= self.max_evals

    def __call__(self, w):
        if self.exhausted:
            return -np.inf
        v = self.f(w)
        self.n += 1
        if v > self.best_f:
            self.best_f = v
            self.best_w = w.copy()
        self.trace.append(self.best_f)
        return v


def random_simplex(rng, n, lb=LB):
    return project_simplex(rng.dirichlet(np.ones(n)), lb)


# ------------------------------------------------------------------ IOA ----
def ioa(f, n=11, N=30, T=1000, K=5, seed=42, c_covert=0.5, c_overt=0.3,
        sigma0=0.05, reinit_frac=0.10, lb=LB, max_evals=6000):
    """Intelligence Operatives Optimization adapted to weight vectors: static cells (i mod K),
    attraction to cell best (covert channel) and global best (overt channel), annealed Gaussian
    perturbation (counter-intelligence), greedy (1+1) acceptance (reliability assessment),
    random immigrants replacing the worst 10 % each sweep (misinformation filtering), with
    the incumbent protected. Random initialisation; stops when the evaluation budget is spent."""
    rng = np.random.default_rng(seed)
    B = Budget(f, max_evals)
    pop = np.array([random_simplex(rng, n, lb) for _ in range(N)])
    fit = np.array([B(w) for w in pop])
    cells = np.arange(N) % K
    T_eff = max(1, (max_evals - N) // (N + max(1, int(round(reinit_frac * N)))))
    for t in range(T_eff):
        if B.exhausted:
            break
        sigma = sigma0 * (1.0 - t / T_eff)
        gbest = pop[np.argmax(fit)]
        for k in range(K):
            idx = np.where(cells == k)[0]
            cbest = pop[idx[np.argmax(fit[idx])]]
            for i in idx:
                if B.exhausted:
                    break
                r1, r2 = rng.random(n), rng.random(n)
                cand = pop[i] + c_covert * r1 * (cbest - pop[i]) + c_overt * r2 * (gbest - pop[i]) \
                    + rng.normal(0.0, sigma, n)
                cand = project_simplex(cand, lb)
                fc = B(cand)
                if fc > fit[i]:
                    pop[i], fit[i] = cand, fc
        m = max(1, int(round(reinit_frac * N)))
        worst = np.argsort(fit)[:m]
        gi = np.argmax(fit)
        for i in worst:
            if i == gi or B.exhausted:
                continue
            pop[i] = random_simplex(rng, n, lb)
            fit[i] = B(pop[i])
    return B


# ------------------------------------------------------------------ PSO ----
def pso(f, n=11, N=30, seed=0, w_in=0.72, c1=1.49, c2=1.49, vclip=0.1, lb=LB, max_evals=6000):
    rng = np.random.default_rng(seed)
    B = Budget(f, max_evals)
    pos = np.array([random_simplex(rng, n, lb) for _ in range(N)])
    vel = rng.normal(0, 0.02, (N, n))
    fit = np.array([B(p) for p in pos])
    pbest, pbf = pos.copy(), fit.copy()
    while not B.exhausted:
        g = pbest[np.argmax(pbf)]
        r1, r2 = rng.random((N, n)), rng.random((N, n))
        vel = w_in * vel + c1 * r1 * (pbest - pos) + c2 * r2 * (g - pos)
        vel = np.clip(vel, -vclip, vclip)
        new = np.array([project_simplex(p, lb) for p in pos + vel])
        vel = new - pos          # velocity corrected after repair
        pos = new
        fit = np.array([B(p) for p in pos])
        imp = fit > pbf
        pbest[imp], pbf[imp] = pos[imp], fit[imp]
    return B


# ------------------------------------------------------------------- DE ----
def de(f, n=11, N=30, seed=0, F=0.6, CR=0.9, lb=LB, max_evals=6000):
    rng = np.random.default_rng(seed)
    B = Budget(f, max_evals)
    pop = np.array([random_simplex(rng, n, lb) for _ in range(N)])
    fit = np.array([B(p) for p in pop])
    while not B.exhausted:
        for i in range(N):
            if B.exhausted:
                break
            a, b, c = rng.choice([j for j in range(N) if j != i], 3, replace=False)
            mutant = pop[a] + F * (pop[b] - pop[c])
            mask = rng.random(n) < CR
            mask[rng.integers(n)] = True
            trial = project_simplex(np.where(mask, mutant, pop[i]), lb)
            ft = B(trial)
            if ft >= fit[i]:
                pop[i], fit[i] = trial, ft
    return B


# ------------------------------------------------------------------- GA ----
def ga(f, n=11, N=30, seed=0, p_mut=0.2, sigma=0.03, alpha=0.5, elite=2, tournament=2,
       lb=LB, max_evals=6000):
    rng = np.random.default_rng(seed)
    B = Budget(f, max_evals)
    pop = np.array([random_simplex(rng, n, lb) for _ in range(N)])
    fit = np.array([B(p) for p in pop])

    def select():
        idx = rng.integers(N, size=tournament)
        return pop[idx[np.argmax(fit[idx])]]

    while not B.exhausted:
        order = np.argsort(-fit)
        new = [pop[i].copy() for i in order[:elite]]
        newf = [fit[i] for i in order[:elite]]
        while len(new) < N and not B.exhausted:
            p1, p2 = select(), select()
            lo, hi = np.minimum(p1, p2), np.maximum(p1, p2)
            span = hi - lo
            child = rng.uniform(lo - alpha * span, hi + alpha * span)
            child = child + (rng.random(n) < p_mut) * rng.normal(0, sigma, n)
            child = project_simplex(child, lb)
            new.append(child)
            newf.append(B(child))
        if len(new) < N:
            break
        pop, fit = np.array(new), np.array(newf)
    return B


# ---------------------------------------------------------- random search ---
def random_search(f, n=11, seed=0, lb=LB, max_evals=6000):
    rng = np.random.default_rng(seed)
    B = Budget(f, max_evals)
    while not B.exhausted:
        B(random_simplex(rng, n, lb))
    return B


# ----------------------------------------------------- constrained SLSQP ----
def most_discriminating(std_fn, delta, w0=W0, lb=LB, starts=20, seed=0, sigma_start=0.03):
    """max std_fn(w) subject to sum(w) = 1, w >= lb, 0.5 * sum|w - w0| <= delta.
    Multi-start SLSQP (first start = w0, then random perturbations of w0). Returns (w, value)."""
    rng = np.random.default_rng(seed)
    n = len(w0)
    cons = [{"type": "eq", "fun": lambda w: w.sum() - 1.0},
            {"type": "ineq", "fun": lambda w: delta - 0.5 * np.abs(w - w0).sum()}]
    best = None
    for k in range(starts):
        x0 = w0.copy() if k == 0 else project_simplex(w0 + rng.normal(0, sigma_start, n), lb)
        r = minimize(lambda w: -std_fn(w), x0, method="SLSQP", bounds=[(lb, 1.0)] * n,
                     constraints=cons, options={"maxiter": 500, "ftol": 1e-12})
        w = project_simplex(r.x, lb)
        d = 0.5 * np.abs(w - w0).sum()
        if d > delta + 1e-6:          # shrink toward the prior until the TV constraint holds
            w = project_simplex(w0 + (w - w0) * (delta / d) * 0.999, lb)
        v = std_fn(w)
        if best is None or v > best[1]:
            best = (w, v)
    if best is None:                  # cannot happen, kept for safety
        best = (w0.copy(), std_fn(w0))
    return best


def tv(w, w0=W0):
    return 0.5 * np.abs(np.asarray(w) - w0).sum()
